# PHP KYC Library

## Setup:
1. Minimum requirement: PHP 7.0+
2. Copy library to your web server.
3. Install phpseclib (within library directory):
```
composer install
```
4. Copy ```satusehat.ini.template``` ke ```satusehat.ini```. Sesuaikan ```client_id```, ```client_secret``` dan ```environment```.

## Start
Open index.php in your browser